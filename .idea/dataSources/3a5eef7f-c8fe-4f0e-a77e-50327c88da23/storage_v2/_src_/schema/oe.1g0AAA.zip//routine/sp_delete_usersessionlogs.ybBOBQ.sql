create procedure SP_DELETE_UserSessionLogs(IN SessionIdx varchar(200))
  BEGIN
DELETE FROM UserSessionLog WHERE SessionId = SessionIdx ;
END;

