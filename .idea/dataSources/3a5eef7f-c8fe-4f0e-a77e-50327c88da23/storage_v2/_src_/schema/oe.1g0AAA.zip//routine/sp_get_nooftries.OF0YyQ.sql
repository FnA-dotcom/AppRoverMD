create procedure SP_GET_noOfTries(IN UserIdx varchar(100))
  BEGIN
SELECT IFNULL(No_of_tries,0) FROM WrongPasswordsAttempts WHERE UserId = UserIdx;
END;

