create procedure SP_GET_AppVersion()
  BEGIN
SELECT Version FROM AppVersion WHERE Status=0 ;
END;

