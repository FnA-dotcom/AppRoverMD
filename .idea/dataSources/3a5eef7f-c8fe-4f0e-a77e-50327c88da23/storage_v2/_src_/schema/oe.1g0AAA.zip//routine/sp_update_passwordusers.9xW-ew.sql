create procedure SP_UPDATE_PasswordUsers(IN FacilityIndex int, IN UpdatedPassword varchar(200))
  BEGIN
UPDATE sysusers SET `password` = UpdatedPassword WHERE clientid = FacilityIndex ;
END;

