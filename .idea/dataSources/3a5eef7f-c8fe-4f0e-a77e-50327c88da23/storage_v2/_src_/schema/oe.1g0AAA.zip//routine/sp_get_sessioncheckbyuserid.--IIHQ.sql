create procedure SP_GET_SessionCheckbyUserId(IN UserIdx varchar(200))
  BEGIN
SELECT COUNT(*) FROM UserSessionLog WHERE UserId = UserIdx ;
END;

