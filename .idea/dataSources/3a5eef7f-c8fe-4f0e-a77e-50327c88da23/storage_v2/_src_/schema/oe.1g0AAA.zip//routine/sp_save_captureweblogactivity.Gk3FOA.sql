create procedure SP_SAVE_captureWebLogActivity(IN UserIdx varchar(255), IN FacilityIndex int, IN WebAction varchar(200),
                                               IN UserIP  varchar(200), IN Status int, IN CreatedDate varchar(255))
  BEGIN

SET @UserId = UserIdx;
SET @FacilityIndex = FacilityIndex;
SET @WebAction = WebAction;
SET @UserIP = UserIP;
SET @Status = Status;
SET @CreatedDate = CreatedDate;


SET @l_sql = CONCAT( 'INSERT INTO WebLogActivity ( UserId, FacilityIndex, WebAction, UserIP, Status, CreatedDate) 
											VALUES (?,?,?,?,?,?) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @UserId, @FacilityIndex ,  @WebAction, @UserIP,  @Status, @CreatedDate;
DEALLOCATE PREPARE stmt;
END;

