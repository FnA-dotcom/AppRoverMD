create procedure SP_UPDATE_NoOfTriesWrongAttempted(IN UserIdx varchar(200))
  BEGIN
UPDATE WrongPasswordsAttempts SET No_of_tries = No_of_tries+1 WHERE UserId = UserIdx;
END;

