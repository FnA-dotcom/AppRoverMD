create procedure SP_SAVE_boltConnectionFailuers(IN DeviceId varchar(255), IN SessionResponse varchar(255),
                                                IN UserIP   varchar(200), IN Status int, IN UserId varchar(200))
  BEGIN

SET @DeviceId = DeviceId;
SET @SessionResponse = SessionResponse;
SET @UserIP = UserIP;
SET @Status = Status;
SET @UserId = UserId;


SET @l_sql = CONCAT( 'INSERT INTO Database.BoltDeviceConnectionFailures (DeviceId,SessionResponse,Status,CreatedDate,UserId,UserIP) VALUES (?,?,?,NOW(),?,?) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @DeviceId, @SessionResponse , @Status,  @UserId , @UserIP;
DEALLOCATE PREPARE stmt;
END;

