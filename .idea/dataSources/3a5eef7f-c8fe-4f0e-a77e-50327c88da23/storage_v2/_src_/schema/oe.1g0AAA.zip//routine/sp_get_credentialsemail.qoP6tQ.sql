create procedure SP_GET_CredentialsEmail()
  BEGIN
SELECT HostName,EmailUserId,EmailPassword,SMTP,`Port`,Authentication,EmailTo FROM EmailCredentials WHERE `Status` = 0;
END;

