create procedure SP_GET_UserCheckSession(IN FacilityIdx int, IN UserIdx varchar(200))
  BEGIN
SELECT COUNT(*) FROM UserSessionLog WHERE UserId = UserIdx AND FacilityIndex = FacilityIdx ;
END;

