create procedure SP_SAVE_SessionUsers(IN UserIdx varchar(255), IN FacilityIndex int, IN UserIP varchar(200),
                                      IN Status  int, IN SessionIdx varchar(200))
  BEGIN

SET @UserId = UserIdx;
SET @FacilityIndex = FacilityIndex;
SET @UserIP = UserIP;
SET @Status = Status;
SET @SessionId = SessionIdx;


SET @l_sql = CONCAT( 'INSERT INTO UserSessionLog ( UserId, FacilityIndex, UserIP, Status, CreatedDate, SessionId) VALUES (?,?,?,?,NOW(),?) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @UserId, @FacilityIndex , @UserIP,  @Status, @SessionId;
DEALLOCATE PREPARE stmt;
END;

