create procedure SP_GET_MobUserCount(IN UserIdx varchar(250), IN Passwordx varchar(250))
  BEGIN
SELECT COUNT(*),a.UserName, b.PRF_name, b.QRF_name, b.Id
FROM MobileUsers a
STRAIGHT_JOIN clients b ON a.ClientIndex = b.Id
WHERE 
upper(trim(a.UserId))= UserIdx AND 
a.Password= Passwordx AND a.Status = 0;
END;

