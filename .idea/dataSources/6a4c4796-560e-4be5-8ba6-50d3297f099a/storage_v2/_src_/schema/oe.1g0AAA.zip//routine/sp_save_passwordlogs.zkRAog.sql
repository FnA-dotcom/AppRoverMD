create procedure SP_SAVE_PasswordLogs(IN OldPassword   varchar(200), IN NewPassword varchar(200),
                                      IN UserId        varchar(200), IN FacilityIndex int, IN CreatedBy varchar(200),
                                      IN UserIP        varchar(200))
  BEGIN

SET @OldPassword = OldPassword;
SET @NewPassword = NewPassword;
SET @UserId = UserId;
SET @FacilityIndex = FacilityIndex;
SET @CreatedBy = CreatedBy;
SET @UserIP = UserIP;


SET @l_sql = CONCAT( 'INSERT INTO oe.PasswordHistory (OldPassword, NewPassword, UserId, FacilityIndex, Status, CreatedDate, CreatedBy, UserIP) VALUES (?,?,?,?,0,NOW(),?,?) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @OldPassword, @NewPassword ,  @UserId, @FacilityIndex, @CreatedBy, @UserIP;
DEALLOCATE PREPARE stmt;
END;

