create procedure SP_GET_AuthorizationConnect(IN FlagVal int, IN ClientIdx int)
  BEGIN
SELECT EndPoint,UserName,`Password`,MerchantId,Currency FROM oe.CardConnectCredentials WHERE TypeFlag = FlagVal AND ClientId = ClientIdx;
END;

