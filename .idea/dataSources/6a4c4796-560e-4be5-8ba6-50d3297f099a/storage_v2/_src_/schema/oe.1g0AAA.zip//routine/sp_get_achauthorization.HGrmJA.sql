create procedure SP_GET_ACHAuthorization(IN ClientIdx int)
  BEGIN
SELECT EndPoint,UserName,`Password`,MID,Currency FROM oe.ACHCredentials WHERE FacilityIndex = ClientIdx AND Status = 0;
END;

