create procedure SP_GET_AuthorizationConnect(IN FlagVal int)
  BEGIN
SELECT EndPoint,UserName,`Password`,MerchantId,Currency FROM CardConnectCredentials WHERE TypeFlag = FlagVal;
END;

