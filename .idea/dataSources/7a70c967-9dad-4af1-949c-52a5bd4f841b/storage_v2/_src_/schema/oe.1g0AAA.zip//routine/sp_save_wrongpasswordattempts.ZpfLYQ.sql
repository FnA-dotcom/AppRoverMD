create procedure SP_SAVE_WrongPasswordAttempts(IN UserIdx     varchar(255), IN Passwordx varchar(255), IN NoOfTries int,
                                               IN UserIP      varchar(255), IN FacilityIndex int, IN Status int,
                                               IN CreatedDate varchar(255))
  BEGIN

SET @UserId = UserIdx;
SET @Password = Passwordx;
SET @NoOfTries = NoOfTries;
SET @UserIP = UserIP;
SET @FacilityIndex = FacilityIndex;
SET @Status = Status;
SET @CreatedDate = CreatedDate;


SET @l_sql = CONCAT( 'INSERT INTO WrongPasswordsAttempts ( UserId, Password, No_of_tries, UserIP, FacilityIndex, Status, CreatedDate) 
											VALUES (?,?,?,?,?,?,?) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @UserId, @Password , @NoOfTries, @UserIP, @FacilityIndex , @Status, @CreatedDate;
DEALLOCATE PREPARE stmt;
END;

