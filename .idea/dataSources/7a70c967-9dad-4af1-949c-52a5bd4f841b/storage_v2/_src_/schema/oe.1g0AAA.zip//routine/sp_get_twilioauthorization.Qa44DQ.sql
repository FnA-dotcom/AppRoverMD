create procedure SP_GET_TwilioAuthorization()
  BEGIN
SET @query  = CONCAT('SELECT AccountSID,AuthToken FROM TwilioConfiguration WHERE `Status` = 0');
PREPARE stmt FROM @query ;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END;

