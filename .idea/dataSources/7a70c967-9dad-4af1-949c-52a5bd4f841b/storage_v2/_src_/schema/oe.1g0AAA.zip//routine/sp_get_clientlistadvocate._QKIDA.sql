create procedure SP_GET_clientListAdvocate(IN facilityIdx int)
  BEGIN

SET @facilityIdx = facilityIdx;

-- SET @query  = CONCAT('SELECT Id,Name FROM oe.clients WHERE Id = ? AND `Status` = 0;');
SET @query  = CONCAT('SELECT Id,Name,Status FROM oe.clients WHERE Id = ?');
PREPARE stmt FROM @query ;
EXECUTE stmt USING @facilityIdx;
DEALLOCATE PREPARE stmt;
END;

