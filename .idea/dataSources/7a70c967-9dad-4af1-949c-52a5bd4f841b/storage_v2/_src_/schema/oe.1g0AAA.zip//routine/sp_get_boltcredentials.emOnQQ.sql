create procedure SP_GET_BoltCredentials(IN facilityIdx int)
  BEGIN

SET @facilityIdx = facilityIdx;

SET @query  = CONCAT('Select IFNULL(COUNT(*),0) from oe.BoltClientProperties WHERE ClientId = ? AND Status = 0');
PREPARE stmt FROM @query ;
EXECUTE stmt USING @facilityIdx;
DEALLOCATE PREPARE stmt;
END;

