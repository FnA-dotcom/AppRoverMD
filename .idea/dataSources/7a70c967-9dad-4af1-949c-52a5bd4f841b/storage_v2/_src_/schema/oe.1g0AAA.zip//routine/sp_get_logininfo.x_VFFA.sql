create procedure SP_GET_LoginInfo(IN UserIdx varchar(255), IN Passwordx varchar(255))
  BEGIN
-- SELECT IFNULL(count(*),0),IFNULL(a.UserType,'-'),IFNULL(a.Enabled,0),
-- IFNULL(ltrim(rtrim(a.UserName)),'-'),IFNULL(a.clientid,0),IFNULL(b.menu,'-'), IFNULL(b.FontColor,''), IFNULL(b.name,''), 
-- IFNULL(b.dbname,''), IFNULL(b.DirectoryName,''),IFNULL(b.FontColor,'white'),indexptr
-- FROM sysusers  a
-- STRAIGHT_JOIN clients b ON a.clientid = b.Id
-- WHERE upper(trim(a.userid)) = UserIdx 
-- AND a.password= Passwordx;

SELECT IFNULL(count(*),0),IFNULL(a.UserType,'-'),IFNULL(a.Enabled,0),
IFNULL(ltrim(rtrim(a.UserName)),'-'),IFNULL(a.clientid,0),IFNULL(b.menu,'-'), IFNULL(b.FontColor,''), IFNULL(b.name,''), 
IFNULL(b.dbname,''), IFNULL(b.DirectoryName,''),IFNULL(b.FontColor,'white'), a.indexptr,
IFNULL(DATE_FORMAT(a.password_expiry,'%Y-%m-%d'),''),DATE_FORMAT(NOW(),'%Y-%m-%d'), IFNULL(a.MaxRetryAllowed,'5'),
IFNULL(a.PRetry,'0'), IFNULL(a.LoginCount,0),
IFNULL(datediff(DATE_FORMAT(NOW(),'%Y-%m-%d %T'),IFNULL(DATE_FORMAT(a.PChangeDate,'%Y-%m-%d %T'),'0000-00-00')),0),
IFNULL(a.LocationIdx,0),IFNULL(a.isAdmin,0),IFNULL(a.isPwdChanged,0)
FROM sysusers  a
STRAIGHT_JOIN clients b ON a.clientid = b.Id
WHERE upper(trim(a.userid)) = UserIdx 
AND a.password= Passwordx;
END;

