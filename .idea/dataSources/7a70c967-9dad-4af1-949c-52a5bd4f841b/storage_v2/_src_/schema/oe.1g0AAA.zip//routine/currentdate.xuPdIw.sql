create procedure CurrentDate()
  BEGIN
SELECT  NOW();
END;

