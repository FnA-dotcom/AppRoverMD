create procedure SP_GET_getPaymentFacilityDetails(IN facilityIdx int)
  BEGIN
SELECT dbname,FullName FROM oe.clients WHERE Id=facilityIdx;
END;

