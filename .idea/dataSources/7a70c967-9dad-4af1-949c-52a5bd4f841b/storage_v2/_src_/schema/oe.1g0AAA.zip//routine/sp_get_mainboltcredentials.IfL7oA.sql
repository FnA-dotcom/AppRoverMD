create procedure SP_GET_MainBoltCredentials(IN FlagVal int)
  BEGIN
SELECT Site,URL,Currency FROM oe.BOLTCredentials WHERE FlagType = FlagVal;
END;

