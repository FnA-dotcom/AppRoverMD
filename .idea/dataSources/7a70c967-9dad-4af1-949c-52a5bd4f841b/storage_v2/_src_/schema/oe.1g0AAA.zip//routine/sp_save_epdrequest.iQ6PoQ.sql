create procedure SP_SAVE_EPDRequest(IN msg         text, IN mrn int, IN requestdate varchar(200), IN RequestType int,
                                    IN ClientIndex int)
  BEGIN

SET @msg = msg;
SET @mrn = mrn;
SET @RequestType = RequestType;
SET @ClientIndex = ClientIndex;


SET @l_sql = CONCAT( 'INSERT INTO oe.request (msg,mrn, requestdate, RequestType, ClientIndex) VALUES (?,?,NOW(),?,?) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @msg, @mrn ,  @RequestType, @ClientIndex;
DEALLOCATE PREPARE stmt;
END;

