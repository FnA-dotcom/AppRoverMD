create procedure SP_GET_SMSSenderDetails(IN advocateIdx int, IN facilityIdx int, IN dbName varchar(20))
  BEGIN
SET @advocateIdx = advocateIdx;
SET @facilityIdx = facilityIdx;
SET @query  = CONCAT('SELECT PhNumber FROM ',dbName,'.`AdvocateSMSNumber` WHERE AdvocateIdx = ? AND FacilityIdx = ? AND `Status` = 0');
PREPARE stmt FROM @query ;
EXECUTE stmt USING @advocateIdx, @facilityIdx;
DEALLOCATE PREPARE stmt;
END;

