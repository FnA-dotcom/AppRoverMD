create procedure SP_GET_TransactionDateWiseReport(IN startDate   varchar(200), IN endDate varchar(200),
                                                  IN facilityIdx int, IN dbName varchar(100))
  BEGIN

SET @startDate = startDate;
SET @endDate = endDate;
SET @facilityIdx = facilityIdx;

-- SET @query  = CONCAT("SELECT * FROM ",dbName,".PatientReg WHERE DATE_FORMAT(CreatedDate,'%d-%m-%Y') BETWEEN ? AND ?;");
SET @query  = CONCAT("SELECT a.ID, CONCAT(IFNULL(a.FirstName,''), ' ', IFNULL(a.LastName,'') , ' ', IFNULL(a.MiddleInitial,'')) AS NAME,
DATE_FORMAT(a.DOB,'%d-%b-%Y') AS DOB, a.Gender, a.MRN, 
b.InvoiceNo,b.ResponseText,b.ResponseStatus,b.RetRef,IFNULL(DATE_FORMAT(b.RetRefDate,'%d-%b-%Y'),00-00-0000) AS RetDate,
b.CreatedDate AS PaymentDate,IFNULL(b.Remarks,'-'),  IFNULL(b.Amount,0), IFNULL(b.AccountNo,'-'), c.`name` AS ClientName, 
b.Id AS CardConnectId, b.refundFlag, b.voidFlag,DATE_FORMAT(b.CreatedDate ,'%d-%b-%Y')
FROM ",dbName,".PatientReg a 
STRAIGHT_JOIN ",dbName,".CardConnectResponses b ON a.MRN = b.PatientMRN AND b.ClientIndex = ?  AND 
 b.CreatedDate BETWEEN ? AND ?  
STRAIGHT_JOIN oe.clients c ON a.ClientIndex = c.Id 
ORDER BY b.CreatedDate DESC;");

PREPARE stmt FROM @query ;
EXECUTE stmt USING @facilityIdx, @startDate, @endDate ;
-- EXECUTE stmt USING @startDate, @endDate;
 -- SELECT @query;
DEALLOCATE PREPARE stmt;

END;

