create procedure SP_GET_smsTemplates()
  BEGIN

SET @query  = CONCAT('Select Id,Name from oe.SmsTemplates;');
PREPARE stmt FROM @query ;
EXECUTE stmt ;
DEALLOCATE PREPARE stmt;
END;

