create procedure SP_GET_facilityListAdvocate(IN userIdx int)
  BEGIN

SET @userIdx = userIdx;

SET @query  = CONCAT('SELECT FacilityIdx FROM `AdvocateSMSNumber` WHERE AdvocateIdx = ? AND Status = 0;');
PREPARE stmt FROM @query ;
EXECUTE stmt USING @userIdx;
DEALLOCATE PREPARE stmt;
END;

