create procedure SP_GET_clientListAdvocateWithoutFac()
  BEGIN

SET @query  = CONCAT('SELECT Id,Name,Status FROM oe.clients WHERE Status = 0');
PREPARE stmt FROM @query ;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END;

