create procedure SP_SAVE_RequestInitiate(IN SentEmail varchar(200), IN PatientMRN int, IN PatientRegIdx int,
                                         IN webStatus int, IN CreatedDate varchar(200), IN SentBy varchar(200),
                                         IN UserIP    varchar(200), IN dbName varchar(200))
  BEGIN
-- SET @enabled = TRUE;
SET @SentEmail = SentEmail;
SET @PatientMRN = PatientMRN;
SET @PatientRegIdx = PatientRegIdx;
SET @webStatus = webStatus;
SET @CreatedDate = CreatedDate;
SET @SentBy = SentBy;
SET @UserIP = UserIP;

-- SELECT dbName;
-- call debug_msg(@enabled, 'my first debug message');
 -- call debug_msg(@enabled, (select concat_ws('','arg11:', dbName)));
SET @query  = CONCAT( 'INSERT INTO ',dbName,'.InvitationRequests  (SentEmail, MRN, PatientRegIdx, Status, CreatedDate, SentBy, UserIP) VALUES (?,?,?,?,?,?,?) ' );

-- SELECT @l_sql;
-- call debug_msg(TRUE, 'This message always shows up');
 PREPARE stmt FROM @query ;

 EXECUTE stmt USING @SentEmail, @PatientMRN ,  @PatientRegIdx, @webStatus, @CreatedDate, @SentBy, @UserIP;
 DEALLOCATE PREPARE stmt;

END;

