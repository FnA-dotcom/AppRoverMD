create procedure SP_GET_maxSMSInfoIdxWithoutFacility(IN dbName varchar(20))
  BEGIN

SET @query  = CONCAT('SELECT MAX(Id) FROM ',dbName,'.SMS_Info WHERE `Status` = 0;');
-- SELECT MAX(Id) FROM dbName.SMS_Info WHERE  `Status` = 0;
PREPARE stmt FROM @query ;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END;

