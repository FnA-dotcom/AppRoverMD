create procedure SP_DELETE_UserSessionLogsByUserId(IN UserIdx varchar(200))
  BEGIN
DELETE FROM UserSessionLog WHERE UserId = UserIdx ;
END;

