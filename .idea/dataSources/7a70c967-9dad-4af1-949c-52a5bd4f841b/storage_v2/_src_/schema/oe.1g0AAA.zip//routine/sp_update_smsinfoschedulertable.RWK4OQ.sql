create procedure SP_UPDATE_SMSInfoSchedulerTable(IN smsTableIdx int, IN dbName varchar(100))
  BEGIN

SET @smsTableIdx = smsTableIdx;

SET @query  = CONCAT('UPDATE ',dbName,'.SMS_Info SET isSchedulerSent = 1, sentSchedulerDate=NOW() WHERE Id = ?;');
PREPARE stmt FROM @query ;
EXECUTE stmt USING @smsTableIdx;
DEALLOCATE PREPARE stmt;

END;

