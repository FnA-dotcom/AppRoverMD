create procedure debug_msg(IN enabled int, IN msg varchar(255))
  BEGIN
  IF enabled THEN
    select concat('** ', msg) AS '** DEBUG:';
  END IF;
END;

