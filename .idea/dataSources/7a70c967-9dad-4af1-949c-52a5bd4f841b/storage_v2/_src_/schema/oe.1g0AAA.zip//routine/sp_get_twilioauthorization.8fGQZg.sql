create procedure SP_GET_TwilioAuthorization(IN dbName varchar(20))
  BEGIN
SET @query  = CONCAT('SELECT AccountSID,AuthToken FROM ',dbName,'.TwilioConfiguration WHERE `Status` = 0');
PREPARE stmt FROM @query ;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
END;

