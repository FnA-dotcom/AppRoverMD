create procedure SP_SAVE_SMSTwilioResponse(IN SMSsID      varchar(200), IN SMSBody varchar(200),
                                           IN SMSDate     varchar(200), IN SMSStatus varchar(200), IN Status int,
                                           IN CreatedBy   int, IN MRN int, IN FacilityIdx int, IN dbName varchar(200))
  BEGIN

SET @SMSsID = SMSsID;
SET @SMSBody = SMSBody;
SET @SMSDate = SMSDate;
SET @SMSStatus = SMSStatus;
SET @Status = Status;
SET @CreatedBy = CreatedBy;
SET @MRN = MRN;
SET @FacilityIdx = FacilityIdx;

SET @l_sql = CONCAT( 'INSERT INTO ',dbName,'.TwilioSMSResponse ( SMSsID, SMSBody, SMSDate, SMSStatus, Status, CreatedDate, CreatedBy, MRN, FacilityIdx) 
			VALUES (?,?,?,?,?,NOW(),?,?,?) ' );

PREPARE stmt FROM @l_sql;

EXECUTE stmt USING @SMSsID , @SMSBody,  @SMSDate, @SMSStatus, @Status, @CreatedBy, @MRN, @FacilityIdx;
DEALLOCATE PREPARE stmt;
END;

