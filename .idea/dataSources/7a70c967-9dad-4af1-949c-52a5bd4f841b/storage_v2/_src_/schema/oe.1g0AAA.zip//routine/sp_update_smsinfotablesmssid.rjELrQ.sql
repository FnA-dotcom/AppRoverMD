create procedure SP_UPDATE_SMSInfoTableSMSSiD(IN smsIdx int, IN SMSSiD varchar(200), IN dbName varchar(100),
                                              IN status varchar(100))
  BEGIN

SET @smsIdx = smsIdx;
SET @SMSSiD = SMSSiD;
SET @status = status;

SET @query  = CONCAT('UPDATE ',dbName,'.SMS_Info SET SMSSiD = ?, Status = ? WHERE Id = ?;');
PREPARE stmt FROM @query ;
EXECUTE stmt USING @SMSSiD, @status, @smsIdx;
DEALLOCATE PREPARE stmt;

END;

