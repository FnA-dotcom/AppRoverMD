create procedure SP_GET_maxSMSInfoIdx(IN facilityIdx int, IN dbName varchar(20))
  BEGIN

SET @facilityIdx = facilityIdx;

SET @query  = CONCAT('SELECT MAX(Id) FROM ',dbName,'.SMS_Info WHERE  FacilityIdx = ? AND `Status` = 0;');
-- SELECT MAX(Id) FROM dbName.SMS_Info WHERE  FacilityIdx = facilityIdx AND `Status` = 0;
PREPARE stmt FROM @query ;
EXECUTE stmt USING @facilityIdx;
DEALLOCATE PREPARE stmt;
END;

