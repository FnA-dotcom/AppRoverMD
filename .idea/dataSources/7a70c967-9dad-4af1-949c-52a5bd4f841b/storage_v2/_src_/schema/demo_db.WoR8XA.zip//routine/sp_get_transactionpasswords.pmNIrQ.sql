create procedure SP_GET_TransactionPasswords(IN Passwordx varchar(200))
  BEGIN
SELECT COUNT(*) FROM TransactionCredentials WHERE UserPassword = Passwordx;
END;

