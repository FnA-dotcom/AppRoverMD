create procedure SP_GET_LoginUserDetails(IN UserId varchar(200))
  BEGIN
SELECT a.username,a.userid,b.Id,b.`name` AS ClientName, a.Password, b.menu
FROM sysusers a
STRAIGHT_JOIN clients b ON a.clientid = b.Id
WHERE upper(trim(a.UserId))=UserId;
END;

