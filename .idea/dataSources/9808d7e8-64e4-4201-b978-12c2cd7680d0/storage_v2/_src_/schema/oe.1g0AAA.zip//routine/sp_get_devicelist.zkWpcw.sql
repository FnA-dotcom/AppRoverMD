create procedure SP_GET_deviceList(IN FacilityIdx int(2))
  BEGIN
Select hsn, DeviceName from oe.BoltDevice where Status = 0 and ClientId = FacilityIdx;
END;

