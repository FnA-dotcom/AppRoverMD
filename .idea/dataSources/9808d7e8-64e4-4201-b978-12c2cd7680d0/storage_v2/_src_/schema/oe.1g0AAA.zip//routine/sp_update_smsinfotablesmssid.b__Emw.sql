create procedure SP_UPDATE_SMSInfoTableSMSSiD(IN smsIdx int, IN SMSSiD varchar(200), IN dbName varchar(100))
  BEGIN

SET @smsIdx = smsIdx;
SET @SMSSiD = SMSSiD;

SET @query  = CONCAT('UPDATE ',dbName,'.SMS_Info SET SMSSiD = ? WHERE Id = ?;');
PREPARE stmt FROM @query ;
EXECUTE stmt USING @SMSSiD, @smsIdx;
DEALLOCATE PREPARE stmt;

END;

