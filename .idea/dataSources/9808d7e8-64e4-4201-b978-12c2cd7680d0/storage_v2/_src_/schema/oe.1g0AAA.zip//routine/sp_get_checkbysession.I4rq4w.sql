create procedure SP_GET_CheckBySession(IN SessionIdx varchar(200))
  BEGIN
SELECT COUNT(*) FROM UserSessionLog WHERE SessionId = SessionIdx ;
END;

