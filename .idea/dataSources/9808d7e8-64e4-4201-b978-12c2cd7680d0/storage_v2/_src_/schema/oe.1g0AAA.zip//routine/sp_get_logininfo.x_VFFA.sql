create procedure SP_GET_LoginInfo(IN UserIdx varchar(255), IN Passwordx varchar(255))
  BEGIN
SELECT IFNULL(count(*),0),IFNULL(a.UserType,'-'),IFNULL(a.Enabled,0),
IFNULL(ltrim(rtrim(a.UserName)),'-'),IFNULL(a.clientid,0),IFNULL(b.menu,'-'), IFNULL(b.FontColor,''), IFNULL(b.name,''), 
IFNULL(b.dbname,''), IFNULL(b.DirectoryName,''),IFNULL(b.FontColor,'white'),indexptr
FROM sysusers  a
STRAIGHT_JOIN clients b ON a.clientid = b.Id
WHERE upper(trim(a.userid)) = UserIdx 
AND a.password= Passwordx;
END;

