create procedure SP_GET_TransactionDataDateWise(IN StartDate    varchar(200), IN EndDate varchar(200), IN ClientIdx int,
                                                IN DataBaseName varchar(200))
  BEGIN
SELECT CONCAT(a.FirstName, ' ', a.LastName , ' ', a.MiddleInitial) AS NAME,DATE_FORMAT(a.DOB,'%d-%b-%Y') AS DOB, a.Gender,b.InvoiceNo,
b.ResponseText,b.ResponseStatus,b.RetRef,IFNULL(DATE_FORMAT(b.RetRefDate,'%d-%b-%Y'),'00-00-0000') AS RetDate,b.CreatedDate,
c.TotalAmount,c.PaidAmount,c.Paid,c.BalAmount,c.Remarks
FROM 
DataBaseName.PatientReg a 
STRAIGHT_JOIN oe.CardConnectResponses b ON a.MRN = b.PatientMRN AND b.ClientIndex = ClientIdx AND b.CreatedDate BETWEEN StartDate AND EndDate
STRAIGHT_JOIN DataBaseName.PaymentReceiptInfo c ON a.MRN = c.PatientMRN;
END;

