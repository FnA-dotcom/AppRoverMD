create procedure CurrentDateFormat()
  BEGIN
SELECT  DATE_FORMAT(NOW(),'%m-%d-%Y');
END;

